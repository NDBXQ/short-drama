"""
语音生成工具
支持文本转语音（TTS）功能
"""
from langchain.tools import tool
from coze_coding_dev_sdk import TTSClient
from coze_coding_utils.runtime_ctx.context import new_context


@tool
def text_to_speech(
    text: str,
    runtime,
    speaker: str = "zh_female_xiaohe_uranus_bigtts",
    audio_format: str = "mp3",
    sample_rate: int = 24000,
    speech_rate: int = 0,
    loudness_rate: int = 0
) -> str:
    """
    将文本转换为语音（TTS）
    
    参数:
        text: 要转换的文本内容
        speaker: 说话人ID，可选值:
            - "zh_female_xiaohe_uranus_bigtts": 小禾（女，通用）
            - "zh_female_vv_uranus_bigtts": Vivi（女，中英文）
            - "zh_male_m191_uranus_bigtts": 云舟（男）
            - "zh_male_taocheng_uranus_bigtts": 小天（男）
            - "zh_female_xueayi_saturn_bigtts": 儿童有声书（女）
            - "zh_male_dayi_saturn_bigtts": 大意（男，视频配音）
            - "zh_female_mizai_saturn_bigtts": 米在（女，视频配音）
        audio_format: 音频格式，可选值: "mp3", "pcm", "ogg_opus"，默认为 "mp3"
        sample_rate: 采样率（Hz），可选值: 8000, 16000, 22050, 24000, 32000, 44100, 48000，默认为 24000
        speech_rate: 语速调整，范围 -50 到 100，默认为 0（正常速度）
        loudness_rate: 音量调整，范围 -50 到 100，默认为 0（正常音量）
    
    返回:
        音频的 URL 链接
    """
    ctx = runtime.context
    # 生成唯一的 uid
    import uuid
    uid = str(uuid.uuid4())
    
    tts_ctx = new_context(method="tts.synthesize")
    
    client = TTSClient(ctx=tts_ctx)
    
    try:
        audio_url, audio_size = client.synthesize(
            uid=uid,
            text=text,
            speaker=speaker,
            audio_format=audio_format,
            sample_rate=sample_rate,
            speech_rate=speech_rate,
            loudness_rate=loudness_rate
        )
        
        return f"✅ 语音生成成功！\n音频链接: {audio_url}\n音频大小: {audio_size} 字节\n说话人: {speaker}"
    except Exception as e:
        return f"❌ 语音生成出错: {str(e)}"


@tool
def get_available_speakers(runtime) -> str:
    """
    获取所有可用的语音列表及其说明
    
    返回:
        可用语音的详细列表
    """
    speakers = """
🎭 可用语音列表：

【通用用途】
1. zh_female_xiaohe_uranus_bigtts - 小禾（女，通用，默认推荐）
2. zh_female_vv_uranus_bigtts - Vivi（女，中英双语）
3. zh_male_m191_uranus_bigtts - 云舟（男，通用）
4. zh_male_taocheng_uranus_bigtts - 小天（男，通用）

【有声书/朗读】
5. zh_female_xueayi_saturn_bigtts - 儿童有声书（女声，适合故事朗读）

【视频配音】
6. zh_male_dayi_saturn_bigtts - 大意（男声，专业配音）
7. zh_female_mizai_saturn_bigtts - 米在（女声，温柔）
8. zh_female_jitangnv_saturn_bigtts - 励志女性（激情）
9. zh_female_meilinvyou_saturn_bigtts - 甜美女友（温柔）
10. zh_female_santongyongns_saturn_bigtts - 顺畅女性（自然）
11. zh_male_ruyayichen_saturn_bigtts - 优雅男性（沉稳）

【角色扮演】
12. saturn_zh_female_keainvsheng_tob - 可爱女生
13. saturn_zh_female_tiaopigongzhu_tob - 调皮公主
14. saturn_zh_male_shuanglangshaonian_tob - 爽朗少年
15. saturn_zh_male_tiancaitongzhuo_tob - 天才同桌
16. saturn_zh_female_cancan_tob - 知性灿灿

💡 使用建议：
- TVC广告推荐：zh_male_dayi_saturn_bigtts（男）或 zh_female_mizai_saturn_bigtts（女）
- 故事叙述推荐：zh_female_xiaohe_uranus_bigtts（自然女声）
- 促销推荐：zh_female_jitangnv_saturn_bigtts（激情）
- 产品介绍推荐：zh_male_ruyayichen_saturn_bigtts（优雅男声）
"""
    return speakers
