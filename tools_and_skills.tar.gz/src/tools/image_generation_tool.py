"""
图像生成工具
支持文生图、图生图功能
"""
from langchain.tools import tool
from coze_coding_dev_sdk import ImageGenerationClient
from coze_coding_utils.runtime_ctx.context import new_context


@tool
def generate_image(
    prompt: str,
    runtime,
    size: str = "2K",
    watermark: bool = False,
    sequential: bool = False,
    max_images: int = 1
) -> str:
    """
    生成图像内容
    
    参数:
        prompt: 图像描述文本，详细描述要生成的图像内容
        size: 图像尺寸，可选值:
            - "2K": 2K 分辨率（默认）
            - "4K": 4K 超高清
            - "WIDTHxHEIGHT": 自定义尺寸，范围 2560x1440 到 4096x4096，如 "3840x2160"
        watermark: 是否添加水印，默认为 False
        sequential: 是否启用连续图像生成（用于故事叙述），默认为 False
        max_images: 最多生成图像数量（1-15），仅在 sequential=True 时有效，默认为 1
    
    返回:
        生成的图像 URL 链接列表
    """
    ctx = runtime.context
    image_ctx = new_context(method="image.generate")
    
    client = ImageGenerationClient(ctx=image_ctx)
    
    try:
        response = client.generate(
            prompt=prompt,
            size=size,
            watermark=watermark,
            sequential_image_generation="auto" if sequential else "disabled",
            sequential_image_generation_max_images=max_images
        )
        
        if response.success:
            image_urls = response.image_urls
            return f"✅ 图像生成成功！\n生成了 {len(image_urls)} 张图像\n图像链接:\n" + "\n".join([f"{i+1}. {url}" for i, url in enumerate(image_urls)])
        else:
            return f"❌ 图像生成失败。错误信息: {response.error_messages}"
    except Exception as e:
        return f"❌ 图像生成出错: {str(e)}"


@tool
def generate_image_from_reference(
    prompt: str,
    reference_image_url: str,
    runtime,
    size: str = "2K",
    watermark: bool = False
) -> str:
    """
    基于参考图像生成新图像（图生图）
    
    参数:
        prompt: 新图像的描述文本，说明如何修改参考图像
        reference_image_url: 参考图像的 URL
        size: 图像尺寸，可选值: "2K", "4K", 或 "WIDTHxHEIGHT"（如 "3840x2160"）
        watermark: 是否添加水印，默认为 False
    
    返回:
        生成的图像 URL 链接
    """
    ctx = runtime.context
    image_ctx = new_context(method="image.generate.from_reference")
    
    client = ImageGenerationClient(ctx=image_ctx)
    
    try:
        response = client.generate(
            prompt=prompt,
            image=reference_image_url,
            size=size,
            watermark=watermark
        )
        
        if response.success:
            image_urls = response.image_urls
            return f"✅ 图生图成功！\n图像链接: {image_urls[0]}\n参考图像: {reference_image_url}"
        else:
            return f"❌ 图生图失败。错误信息: {response.error_messages}"
    except Exception as e:
        return f"❌ 图生图出错: {str(e)}"


@tool
def generate_storyboard_images(
    story_prompt: str,
    runtime,
    num_scenes: int = 5,
    size: str = "2K",
    watermark: bool = False
) -> str:
    """
    生成故事板图像序列（用于 TVC 故事板制作）
    
    参数:
        story_prompt: 故事描述，简要描述整个故事情节
        num_scenes: 场景数量（1-15），默认为 5
        size: 图像尺寸，可选值: "2K", "4K", 或 "WIDTHxHEIGHT"
        watermark: 是否添加水印，默认为 False
    
    返回:
        生成的故事板图像序列 URL 链接
    """
    ctx = runtime.context
    image_ctx = new_context(method="image.generate.storyboard")
    
    client = ImageGenerationClient(ctx=image_ctx)
    
    try:
        response = client.generate(
            prompt=story_prompt,
            size=size,
            watermark=watermark,
            sequential_image_generation="auto",
            sequential_image_generation_max_images=num_scenes
        )
        
        if response.success:
            image_urls = response.image_urls
            return f"✅ 故事板图像生成成功！\n生成了 {len(image_urls)} 个场景\n场景链接:\n" + "\n".join([f"场景 {i+1}: {url}" for i, url in enumerate(image_urls)])
        else:
            return f"❌ 故事板生成失败。错误信息: {response.error_messages}"
    except Exception as e:
        return f"❌ 故事板生成出错: {str(e)}"
