import nextConfig from "eslint-config-next"

const config = [...nextConfig]

export default config
