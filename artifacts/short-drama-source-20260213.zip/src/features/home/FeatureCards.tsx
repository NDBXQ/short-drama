import type { ReactElement } from "react"

/**
 * 首页功能入口卡片（脚本创作/视频创作）
 * @returns {ReactElement} 区块内容
 */
export function FeatureCards(): ReactElement {
  return <></>
}
