import { AgentChatPage } from "@/features/agentChat/AgentChatPage"

export default function Page() {
  return <AgentChatPage />
}
