export type {
  TvcAgentBlock,
  TvcAgentField,
  TvcAgentImageItem,
  TvcAgentResponse,
  TvcAgentSectionItem,
  TvcAgentStep,
  TvcAgentStepContent
} from "@/shared/contracts/tvc/agentTypes"
